package com.example.mascotapet;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
    private static final int REQ_NOTIF = 10;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(40,50,40,40);
        TextView title = new TextView(this); title.setText("Mi Mascota 🐾"); title.setTextSize(30); title.setTextColor(Color.rgb(45,70,135));
        TextView info = new TextView(this); info.setText("Primera versión: tu mascota camina sobre la pantalla y puedes tocarla o arrastrarla.\n\nAndroid requiere permiso para mostrarla encima de otras aplicaciones."); info.setTextSize(17); info.setPadding(0,25,0,25);
        Button start = new Button(this); start.setText("Activar mascota");
        Button stop = new Button(this); stop.setText("Guardar / quitar mascota");
        root.addView(title); root.addView(info); root.addView(start); root.addView(stop); setContentView(root);

        start.setOnClickListener(v -> activate());
        stop.setOnClickListener(v -> stopService(new Intent(this, PetOverlayService.class)));
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
    }
    private void activate() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())); startActivity(i); return;
        }
        Intent s = new Intent(this, PetOverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
    }
    @Override protected void onResume() { super.onResume(); }
}
