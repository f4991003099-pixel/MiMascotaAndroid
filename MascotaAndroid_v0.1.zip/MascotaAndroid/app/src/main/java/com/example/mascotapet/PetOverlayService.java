package com.example.mascotapet;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.ImageView;
import android.widget.Toast;
import android.graphics.drawable.ColorDrawable;

public class PetOverlayService extends Service {
    private WindowManager wm; private ImageView pet; private Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager.LayoutParams lp; private float dx = 5f; private int screenW, screenH; private boolean dragging=false;
    private float downX, downY; private int startX,startY;
    private final Runnable mover = new Runnable(){ public void run(){
        if(pet==null || dragging){ handler.postDelayed(this,40); return; }
        lp.x += (int)dx;
        if(lp.x <= 0){ lp.x=0; dx=Math.abs(dx); }
        int maxX=Math.max(0,screenW-pet.getWidth());
        if(lp.x>=maxX){ lp.x=maxX; dx=-Math.abs(dx); }
        wm.updateViewLayout(pet,lp); handler.postDelayed(this,40);
    }};

    @Override public void onCreate(){ super.onCreate(); createNotification();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE); android.util.DisplayMetrics m=getResources().getDisplayMetrics(); screenW=m.widthPixels; screenH=m.heightPixels;
        pet=new ImageView(this); pet.setImageResource(com.example.mascotapet.R.drawable.mascota); pet.setScaleType(ImageView.ScaleType.FIT_CENTER); pet.setBackground(new ColorDrawable(Color.TRANSPARENT));
        int size=Math.min(screenW/3,420);
        lp=new WindowManager.LayoutParams(size,size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.START; lp.x=screenW/2-size/2; lp.y=Math.max(40,screenH-size-80);
        pet.setOnTouchListener((v,e)->{
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN: dragging=true; downX=e.getRawX(); downY=e.getRawY(); startX=lp.x; startY=lp.y; return true;
                case MotionEvent.ACTION_MOVE: lp.x=startX+(int)(e.getRawX()-downX); lp.y=startY+(int)(e.getRawY()-downY); wm.updateViewLayout(pet,lp); return true;
                case MotionEvent.ACTION_UP: dragging=false; if(Math.abs(e.getRawX()-downX)<20 && Math.abs(e.getRawY()-downY)<20) Toast.makeText(this,"¡Me tocaste! 💙",Toast.LENGTH_SHORT).show(); return true;
            } return true;
        });
        wm.addView(pet,lp); handler.post(mover);
    }
    private void createNotification(){
        String ch="pet"; NotificationManager nm=getSystemService(NotificationManager.class);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(ch,"Mascota",NotificationManager.IMPORTANCE_LOW));
        Intent i=new Intent(this,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n=new Notification.Builder(this,ch).setSmallIcon(android.R.drawable.ic_menu_compass).setContentTitle("Mi Mascota está activa").setContentText("Tu mascota está caminando por la pantalla").setContentIntent(pi).setOngoing(true).build();
        startForeground(7,n);
    }
    @Override public int onStartCommand(Intent i,int flags,int id){ return START_STICKY; }
    @Override public void onDestroy(){ handler.removeCallbacks(mover); if(pet!=null){ try{wm.removeView(pet);}catch(Exception ignored){} pet=null;} super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent i){ return null; }
}
