# Mi Mascota — Android prototype

Primera versión de una mascota flotante estilo escritorio.

## Qué hace
- Solicita permiso para aparecer encima de otras apps.
- Muestra la imagen de referencia como mascota flotante.
- Camina horizontalmente por la pantalla.
- Puedes tocarla y arrastrarla.
- Usa un servicio en primer plano para mantenerla activa.

## Abrir
Abre esta carpeta en Android Studio y ejecuta el proyecto en un teléfono/emulador Android 8.0+.

## Siguiente versión
Conviene sustituir la imagen de referencia por sprites PNG transparentes de caminar, idle, dormir y reaccionar. Después se pueden añadir hambre, sueño, cariño, inventario, sonidos y personalidad.
